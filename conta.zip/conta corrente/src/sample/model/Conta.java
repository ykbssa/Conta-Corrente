package sample.model;

public class Conta {
    String numAgencia;
    String numConta;
    double saldo;

    // Construtor, relacionando os textos com as variaveis
    // Inserindo o saldo da conta
    public Conta(String agencia, String cc){
        numAgencia = agencia;
        numConta = cc;
        saldo = 120;
    }

    // Sacar valor da conta
    // Não é possivel sacar um valor maior que se tenha na conta
    public double sacar(double valor){
        if (saldo>= valor){
            saldo -= valor;
        } else {
            return 0;
        }
        return valor;
    }

    // Depositar valor na conta
    public boolean depositar(double valor){
       if(valor > 0) {
           saldo += valor;
           return true;
       } else {
        return false;
    }
       }
       // Retornando os dados da conta + o saldo
       public String extrato(){
        return "Extrato\n\n\nAgência: " + numAgencia
                + " Conta Corrente:" + numConta
                + "Saldo: " + saldo;
       }
}
