package sample.model;

import sample.model.Conta;

public class Main {
    //Especificando os dados da conta do usuario
    // e mostrando os dados + o extrato no sistema
    public static void main(String[] args) {
        Conta conta = new Conta("55885-65 ", "92452 ");

        System.out.println(conta.extrato());
    }

}
